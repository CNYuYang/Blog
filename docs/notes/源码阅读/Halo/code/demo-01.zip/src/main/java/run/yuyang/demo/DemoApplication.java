package run.yuyang.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@SpringBootApplication
@Controller
public class DemoApplication {


    private static ConfigurableApplicationContext CONTEXT;

    @Autowired
    private Count count;

    public static void main(String[] args) {
        CONTEXT = SpringApplication.run(DemoApplication.class, args);
    }

    @GetMapping("/")
    @ResponseBody
    public String hello() {
        return "Hello Spring\n " + count.num++ + "\n" + "user.dir -> " + System.getProperty("user.dir");
    }

    @GetMapping("/restart/v1")
    public void restart1() {
        CONTEXT.close();
        CONTEXT = SpringApplication.run(DemoApplication.class, CONTEXT.getBean(ApplicationArguments.class).getSourceArgs());
    }

    @GetMapping("/restart/v2")
    public void restart2() {
        Thread thread = new Thread(() -> {
            ApplicationArguments args = CONTEXT.getBean(ApplicationArguments.class);
            CONTEXT.close();
            CONTEXT = SpringApplication.run(DemoApplication.class, args.getSourceArgs());
        });
        thread.start();
    }

    @GetMapping("/restart/v3")
    public void restart3() {
        Thread thread = new Thread(() -> {
            ApplicationArguments args = CONTEXT.getBean(ApplicationArguments.class);
            CONTEXT.close();
            CONTEXT = SpringApplication.run(DemoApplication.class, args.getSourceArgs());
        });
        thread.setDaemon(false);
        thread.start();
    }

    @Bean
    public Count buildCount() {
        Count count = new Count();
        count.num = 0;
        return count;
    }
}
