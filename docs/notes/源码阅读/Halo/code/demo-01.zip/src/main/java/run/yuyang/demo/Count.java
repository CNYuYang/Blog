package run.yuyang.demo;


public class Count {
    public Integer num;
}
